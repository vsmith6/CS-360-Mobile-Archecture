package com.example.mod4milestone;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class View_Holder extends RecyclerView.ViewHolder {
    Button button3;
    TextView name;
    TextView description;
    TextView quantity;

    View_Holder(View itemView) {
        super(itemView);
        name = (TextView) itemView.findViewById(R.id.name);
        description = (TextView) itemView.findViewById(R.id.description);
        quantity = (TextView) itemView.findViewById(R.id.quantity);
        button3 = (Button) itemView.findViewById(R.id.button3);

    }


}
