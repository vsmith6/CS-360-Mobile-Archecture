package com.example.mod4milestone;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import java.util.ArrayList;
import java.util.List;


public class InventoryDB extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "inventory3.db";

    private static InventoryDB mInventoryDb;

    public static InventoryDB getInstance(Context context) {
        if (mInventoryDb == null) {
            mInventoryDb = new InventoryDB(context);
        }
        return mInventoryDb;
    }

    private InventoryDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASS = "password";

    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_NAME = "name";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_QUANTITY = "quantity";

    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table "
                + InventoryTable.TABLE + " ("
                + InventoryTable.COL_NAME + ", "
                + InventoryTable.COL_DESCRIPTION + ", "
                + InventoryTable.COL_QUANTITY + " int "
                +")");

        // Create users table
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_USERNAME + " primary key, " +
                UserTable.COL_PASS + ")");





    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    public List<User> getUsers() {
        List<User> users = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + UserTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setUserId(cursor.getString(0));
                user.setPassword(cursor.getString(1));
                users.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return users;
    }
    public int addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        // Check and see if username exists
        String sql = "select * from "
                + UserTable.TABLE + " where "
                + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = (db.rawQuery(sql, new String[] { user.getUserId() }));

        if  (cursor.getCount() == 0) {
            // If the query returns 0 count then the username doesn't exist and can be added
            ContentValues values = new ContentValues();
            values.put(UserTable.COL_USERNAME, user.getUserId());
            values.put(UserTable.COL_PASS, user.getPassword());
            db.insert(UserTable.TABLE, null, values);
            return 0;
        }
        else {
            return 1;
        }
    }
    // Check to see if username and password match
    public boolean checkCredentials(User user) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE + " where " + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { user.getUserId()});
        if (cursor.moveToFirst()) {
            String storedPass = cursor.getString(1);
            cursor.close();

            if (storedPass.equals(user.getPassword())) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    // Reads item data from database and inserts it into an array list
    public List<Data> getInventoryItems() {
        List<Data> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                Data inventory = new Data();
                inventory.setName(cursor.getString(0));
                inventory.setDescription(cursor.getString(1));
                inventory.setQuantity(cursor.getString(2));
                items.add(inventory);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return items;
    }
    public int addInventory(Data data) {
        SQLiteDatabase db = getWritableDatabase();
        // Check and see if username exists
        String sql = "select * from "
                + InventoryTable.TABLE + " where "
                + InventoryTable.COL_NAME + " = ?";
        Cursor cursor = (db.rawQuery(sql, new String[] { data.getName() }));

        if  (cursor.getCount() == 0) {
            // If the query returns 0 count then the username doesn't exist and can be added
            ContentValues values = new ContentValues();
            values.put(InventoryTable.COL_NAME, data.getName());
            values.put(InventoryTable.COL_DESCRIPTION, data.getDescription());
            values.put(InventoryTable.COL_QUANTITY, data.getQuantity());
            db.insert(InventoryTable.TABLE, null, values);
            return 0;
        }
        else {
            return 1;
        }
    }
    // Call to update the quantity in the database
    public void updateQuantity(Data item, int newTotal) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues newQuantity = new ContentValues();
        newQuantity.put(InventoryTable.COL_QUANTITY, newTotal);
        db.update(InventoryTable.TABLE, newQuantity, InventoryTable.COL_QUANTITY + " = " + item.getQuantity(), null);
    }


    // Call to delete an item in the database
    public void deleteItem(Data item) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "delete from "
                + InventoryTable.TABLE + " where "
                + InventoryTable.COL_NAME + " = ?";
        Cursor cursor = (db.rawQuery(sql, new String[] { item.getName() }));


    }

}
