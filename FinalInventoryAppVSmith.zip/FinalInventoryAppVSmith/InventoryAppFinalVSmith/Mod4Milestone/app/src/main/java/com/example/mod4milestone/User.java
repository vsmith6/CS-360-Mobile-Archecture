package com.example.mod4milestone;

public class User {
    private String mUserId;
    private String mPassword;
    private int mId;

    public User(String userId) {
        mUserId = userId;
    }
    public User(){}

    public String getUserId() {
        return mUserId;
    }

    public void setUserId(String mUserId) {
        this.mUserId = mUserId;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String mPassword) {
        this.mPassword = mPassword;
    }
}
