package com.example.mod4milestone;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;


public class MainActivity3 extends AppCompatActivity {


    public InventoryDB mInventoryDb;
    private TextView mQuantity;
    private TextView mName;
    private TextView mDescription;

    private View.OnClickListener listener;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
      //  ArrayList<Data> items = new ArrayList<>();
        // Singleton

        mInventoryDb = InventoryDB.getInstance(getApplicationContext());
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity3.this));
        RecyclerView_Adapter adapter = new RecyclerView_Adapter(loadInventory(), getApplication(), (RecyclerView_Adapter.OnItemClickListener) listener);


        recyclerView.setAdapter(adapter);


        mName = findViewById(R.id.name);
        mDescription = findViewById(R.id.description);
        mQuantity = findViewById(R.id.quantity);


        listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              String name =  String.valueOf(view.findViewById(R.id.name));
                Toast.makeText(MainActivity3.this, name + " was clicked!", Toast.LENGTH_SHORT).show();
            }
        };
  }


    private List<Data> loadInventory() {
        List<Data> items;
        mInventoryDb.getReadableDatabase();


        items = mInventoryDb.getInventoryItems();


        return items;
    }

    public void deleteItem(View view) {
        mName = findViewById(R.id.name);
        mDescription = findViewById(R.id.description);
        mQuantity = findViewById(R.id.quantity);

        mInventoryDb = InventoryDB.getInstance(getApplicationContext());
        Data mData = new Data();
        mData.setName(this.mName.getText().toString());
        mData.setDescription(this.mDescription.getText().toString());
        mData.setQuantity(this.mQuantity.getText().toString());

        mInventoryDb.deleteItem(mData);

    }

    public void AddItem(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, AddInventoryItem.class);
        startActivity(intent);
    }
    public void ChangeQuantity(View view) {
        // Do something in response to button
    }


}
