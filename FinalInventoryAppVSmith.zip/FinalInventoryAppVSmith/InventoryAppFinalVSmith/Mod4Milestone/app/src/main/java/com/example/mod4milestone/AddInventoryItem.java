package com.example.mod4milestone;

import android.app.Activity;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class AddInventoryItem extends AppCompatActivity {
    public InventoryDB mInventoryDb;
    private EditText mQuantity;
    private EditText mName;
    private EditText mDescription;
    private Data mData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_inventory_item);


    }
    public void saveButtonClick(View view) {
        mName = findViewById(R.id.newName);
        mDescription = findViewById(R.id.newDescription);
        mQuantity = findViewById(R.id.newQuantity);

        mInventoryDb = InventoryDB.getInstance(getApplicationContext());
        Data mData = new Data();
        mData.setName(this.mName.getText().toString());
        mData.setDescription(this.mDescription.getText().toString());
        mData.setQuantity(this.mQuantity.getText().toString());

        mInventoryDb = InventoryDB.getInstance(getApplicationContext());
        mInventoryDb.addInventory(mData);
    }


}
