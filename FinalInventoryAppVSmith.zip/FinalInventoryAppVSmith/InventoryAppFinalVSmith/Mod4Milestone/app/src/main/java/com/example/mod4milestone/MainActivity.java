package com.example.mod4milestone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private Button settingsBtn;
    public InventoryDB mInventoryDb;
    private EditText mUserId;
    private EditText mPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // initializing our button.
        settingsBtn = findViewById(R.id.idBtnSettings);

        // Singleton
        mInventoryDb = InventoryDB.getInstance(getApplicationContext());
        mInventoryDb.getReadableDatabase();



        // adding on click listener for our button.
        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // opening a new intent to open settings activity.
                Intent i = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(i);
            }
        });
    }
    public void sendLogin(View view) {
        mUserId = findViewById(R.id.editTextTextPersonName2);
        mPass = findViewById(R.id.editTextTextPersonName);
        User mSignIn = new User();
        mSignIn.setUserId(this.mUserId.getText().toString());
        mSignIn.setPassword(this.mPass.getText().toString());
        boolean authentic = mInventoryDb.checkCredentials(mSignIn);
      //  String mUsername = mUserId.getText().toString();
        if (authentic) {
            Toast.makeText(this, "Welcome  !", Toast.LENGTH_LONG).show();

        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);
        }
        else {
            Toast.makeText(this, "Information is not correct, try again.", Toast.LENGTH_SHORT).show();
        }
    }
    public void sendRegister(View view) {
        mUserId = findViewById(R.id.editTextTextPersonName2);
        mPass = findViewById(R.id.editTextTextPersonName);
        int success = 2;

        if ((!mUserId.getText().toString().equals("")) && (!mPass.getText().toString().equals(""))) {
            User mSignIn = new User();
            mSignIn.setUserId(this.mUserId.getText().toString());
            mSignIn.setPassword(this.mPass.getText().toString());

            success = mInventoryDb.addUser(mSignIn);
            if (success == 0) {
                Intent intent = new Intent(this, MainActivity.class);

                startActivity(intent);
                Toast.makeText(this, "Welcome  please log in", Toast.LENGTH_LONG).show();
            }
        }
        else {
            Toast.makeText(this, "Please select a username and password.", Toast.LENGTH_SHORT).show();

        }

    }
}