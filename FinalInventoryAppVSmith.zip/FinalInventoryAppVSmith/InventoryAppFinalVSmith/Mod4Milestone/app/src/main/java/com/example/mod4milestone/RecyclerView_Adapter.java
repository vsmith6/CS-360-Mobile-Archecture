package com.example.mod4milestone;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Collections;
import java.util.List;

public class RecyclerView_Adapter extends RecyclerView.Adapter<View_Holder>{


    ImageView imageView;
    Button button3;



    List<Data> list
            = Collections.emptyList();

    Context context;
    public interface OnItemClickListener {
        void onItemClick(View itemView, int position);
    }
   private OnItemClickListener listener;

    public RecyclerView_Adapter(List<Data> list,
                                Context context, OnItemClickListener listener)
    {
        this.list = list;
        this.context = context;
        this.listener = listener;
    }

    @Override
    public View_Holder
    onCreateViewHolder(ViewGroup parent,
                       int viewType)
    {

        Context context
                = parent.getContext();
        LayoutInflater inflater
                = LayoutInflater.from(context);

        // Inflate the layout

        View imageView
                = inflater
                .inflate(R.layout.row_layout,
                        parent, false);

        View_Holder viewHolder
                = new View_Holder(imageView);

        return viewHolder;
    }


    @Override
    public void
    onBindViewHolder(@NonNull View_Holder viewHolder, int position)
    {
        Data data = list.get(position);
        viewHolder.name
                .setText(list.get(position).name);
        viewHolder.description
                .setText(list.get(position).description);
        viewHolder.quantity
                .setText(list.get(position).quantity);
        viewHolder.button3.findViewById(R.id.button3);



        viewHolder.itemView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                int index = viewHolder.getAdapterPosition();
                String name = list.get(index).name;
                Toast.makeText(context, name, Toast.LENGTH_SHORT).show();
            }

        });

    }

    @Override
    public int getItemCount()
    {
        return list.size();
    }

    @Override
    public void onAttachedToRecyclerView(
            RecyclerView recyclerView)
    {
        super.onAttachedToRecyclerView(recyclerView);
    }





}